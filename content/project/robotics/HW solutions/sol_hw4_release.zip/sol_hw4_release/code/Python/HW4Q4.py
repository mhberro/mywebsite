#!/usr/bin/env python3
# -*- coding: utf-8 -*-


import numpy as np
import csv
from sklearn.model_selection import train_test_split
from sklearn.neural_network import MLPClassifier
from sklearn.svm import SVC


import matplotlib.pyplot as plt
from matplotlib.colors import ListedColormap


raw = []
with open('marriage.csv') as cf:
    readcsv = csv.reader(cf, delimiter=',')
    for row in readcsv:
        raw.append(row)
        
data = np.array(raw).astype(np.float)
x = data[:, 0:-1]
y = data[:, -1]

images = np.genfromtxt('data.dat').T
imlabel = np.genfromtxt('label.dat')



def twoClassifier(target_x, target_y, ntrials):
    
    rate_sv, rate_nn = np.zeros(ntrials),np.zeros(ntrials)
    for ii in range(ntrials):
        
        X_train, X_test, y_train, y_test = train_test_split(target_x, target_y, test_size=0.2)
        ntest = len(y_test)
        
        # svm
        sv = SVC(kernel='linear', random_state=0).fit(X_train,y_train)
        y_pred_sv = sv.predict(X_test)
        rate_sv[ii] = sum(y_pred_sv==y_test)/ntest
        
        # Neural network
        nn = MLPClassifier(hidden_layer_sizes=(5,2), max_iter=300, random_state=0).fit(X_train,y_train)
        y_pred_nn = nn.predict(X_test)
        rate_nn[ii] = sum(y_pred_nn==y_test)/ntest
    
    
    acc_sv = rate_sv.mean()
    acc_nn = rate_nn.mean()   
    return acc_sv, acc_nn


# define a function to plot decision boundary
# Reference
# https://stackoverflow.com/questions/45075638/graph-k-nn-decision-boundaries-in-matplotlib
def plot_decision_boundary(model, title, x_train, x_test, y_train):
    h = 0.01
    cmap_light = ListedColormap(['#FFAAAA',  '#AAAAFF'])
    cmap_bold = ListedColormap(['#FF0000',  '#0000FF'])

    x_min, x_max = x_train[:,0].min(), x_train[:,0].max() 
    y_min, y_max = x_train[:,1].min(), x_train[:,1].max()

    xx, yy = np.meshgrid(np.arange(x_min, x_max, h),
                         np.arange(y_min, y_max, h))

    Z = model.predict(np.c_[xx.ravel(), yy.ravel()])

    # Put the result into a color plot
    Z = Z.reshape(xx.shape)
    plt.figure()
    plt.pcolormesh(xx, yy, Z, cmap=cmap_light)

    # Also plot the training points
    plt.scatter(x_train[:,0], x_train[:,1], c=y_train, cmap=cmap_bold)
    plt.xlim(xx.min(), xx.max())
    plt.ylim(yy.min(), yy.max())
    plt.title(title)



# accuracy 
mrg_svm, mrg_nn = twoClassifier(x, y,  1)
print('result for marriage data')
print('test accuracy of SVM: ', mrg_svm)
print('test accuracy of Neural Network: ', mrg_nn)


print('\n')
im_svm, im_nn = twoClassifier(images, imlabel,  1)
print('result for MNIST data')
print('test accuracy of SVM: ', im_svm)
print('test accuracy of Neural Network: ', im_nn)

# boundary plots
X_train, X_test, y_train, y_test = train_test_split(x[:, 0:2], y, test_size=0.2)
sv = SVC(kernel='linear').fit(X_train, y_train)
plot_decision_boundary(sv, 'SVM', X_train, X_test, y_train)

nn = MLPClassifier((5,2)).fit(X_train, y_train)
plot_decision_boundary(nn, 'Neural Network', X_train, X_test, y_train)



