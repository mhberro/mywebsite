clear; close all;
load data
load label
x = data';
y1 = double(trueLabel'==6);
y = categorical(y1);
N = size(x, 1);
ntrial = 10; 

rate_svm = zeros(1, ntrial);
rate_nn = zeros(1, ntrial);


%% 
for ii = 1:ntrial

[train_idx, test_idx] = divide_data(N, 0.8);
    nt = length(test_idx);

    % svm
    mdl_svm = fitclinear(x(train_idx,:), y(train_idx));
    pre_svm = predict(mdl_svm, x(test_idx, :));
    rate_svm(ii) = sum(pre_svm ==y(test_idx))/nt;

    
    % neural network
    net = feedforwardnet([5,2]);
    net.trainParam.showWindow = false;
    net.divideParam.trainRatio = 1;
    net.trainParam.mu = 0.1;
    net = train(net, x(train_idx,:)', y1(train_idx)');
    
    pre_nn = net(x(test_idx,:)')';
    pre_nn = round(pre_nn);
    rate_nn(ii) = sum(pre_nn == y1(test_idx))/nt;
    
end

acc_svm = mean(rate_svm)
acc_nn = mean(rate_nn)


