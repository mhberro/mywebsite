clear; close all;
rng(1)
raw = csvread('marriage.csv');

% %%%% select all features vs 2 features
flag = 0; % '0': all features; '1': 2 features 

if flag ==0
    x = raw(:, 1:end-1); % all features
else
    x = raw(:, 1:2);    % 2 features
end

y1 = raw(:, end);
y = categorical(y1);

N = size(x, 1);

%% complete data set
% to achieve more accurate results, we repeat the test multiple times and
% take the average of the results.
ntrial = 100; 
rate_svm = zeros(1, ntrial);
rate_nn = zeros(1, ntrial);

for ii =1:ntrial
    [train_idx, test_idx] = divide_data(N, 0.8);
    nt = length(test_idx);

    % svm
    mdl_svm = fitclinear(x(train_idx,:), y(train_idx));
    pre_svm = predict(mdl_svm, x(test_idx, :));
    rate_svm(ii) = sum(pre_svm ==y(test_idx))/nt;
       
    % neural network
    net = feedforwardnet([5,2]);
    net.trainParam.showWindow = false;
    net.trainParam.mu = 1;
    net = train(net, x(train_idx,:)', y1(train_idx)');
    
    pre_nn = net(x(test_idx,:)')';
    pre_nn = round(pre_nn);
    rate_nn(ii) = sum(pre_nn == y1(test_idx))/nt;

end

acc_svm = mean(rate_svm)
acc_nn = mean(rate_nn)



%% part c), decision boudaries: two features
if flag ==1
    models = {mdl_svm, net};
    model_name = {'SVM','Neural Network'};
    x1range = min(x(train_idx,1)):.01:max(x(train_idx,1));
    x2range = min(x(train_idx,2)):.01:max(x(train_idx,2));

    [xx1, xx2] = meshgrid(x1range,x2range);
    XGrid = [xx1(:) xx2(:)];

    idx0 = find(y(test_idx)=='0');
    idx1 = find(y(test_idx)=='1');
    x0test = x(test_idx(idx0), :);
    x1test = x(test_idx(idx1), :);

    figure;
    for ii =1:2
       if ii <2
           predictedDivorce = predict(models{ii}, XGrid);
       else
           predictedDivorce = round(net(XGrid'));
       end
           subplot(1,2,ii);
           gscatter(xx1(:), xx2(:), predictedDivorce,'rgb');
           hold on;
           scatter(x0test(:, 1), x0test(:, 2), 'bo');
           hold on;
           scatter(x1test(:, 1), x1test(:, 2), 'bx');
           title(model_name{ii})
           legend off, axis tight, axis square
           
    end
    legend(categories(y),'Location',[0.35,0.01,0.35,0.05],'Orientation','Horizontal')
end

