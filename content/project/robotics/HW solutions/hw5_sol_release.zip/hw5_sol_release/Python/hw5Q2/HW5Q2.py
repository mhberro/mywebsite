#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Jul  1 19:50:57 2020

@author: PFC
"""

import numpy as np
import csv
from sklearn import tree
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import roc_auc_score
import matplotlib.pyplot as plt

raw=[]
with open('spambase.data') as cf:
    readcsv = csv.reader(cf, delimiter=',')
    for row in readcsv:
        raw.append(row)       
data = np.array(raw).astype(np.float)

x = data[:, :-1]
y = data[:, -1]

# plot the tree##
ctree = tree.DecisionTreeClassifier().fit(x, y)
plt.figure() 
tree.plot_tree(ctree, max_depth=3, filled=True)
# plt.savefig('ctree.pdf')
plt.show()

score_tree = []
score_forest = []

# training both tree and forest with different depth
xtrain, xtest, ytrain, ytest = train_test_split(x, y, test_size=0.2)
for depth in range(1,60): 
    ctree = tree.DecisionTreeClassifier(max_depth = depth).fit(xtrain, ytrain)
    ypre_tree = ctree.predict(xtest)
    score_tree.append(roc_auc_score(ytest, ypre_tree))
    
    cforest = RandomForestClassifier(max_depth = depth).fit(xtrain, ytrain)
    ypre_forest = cforest.predict(xtest)
    score_forest.append(roc_auc_score(ytest, ypre_forest))  
    
    
plt.figure()
plt.plot(score_tree,label='Decision Tree')
plt.plot(score_forest, label='Random Forest')
plt.title("Max Depth verse AUC")
plt.xlabel("Max Depth of Each Tree")
plt.ylabel("AUC score")
plt.legend()
# plt.savefig('auc.pdf')
plt.show()