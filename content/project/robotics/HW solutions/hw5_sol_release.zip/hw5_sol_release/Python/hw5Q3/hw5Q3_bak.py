#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Jul  2 02:28:57 2020

@author: PFC
"""

import numpy as np
import matplotlib.pyplot as plt

from sklearn.preprocessing import PolynomialFeatures
from sklearn.pipeline import make_pipeline
from sklearn.linear_model import Ridge, RidgeCV
        
data= np.loadtxt('copper-new.txt')
x = data[:,1]
y = data[:,0]

# refernce: https://scikit-learn.org/stable/auto_examples/linear_model/plot_polynomial_interpolation.html#sphx-glr-auto-examples-linear-model-plot-polynomial-interpolation-py

X = x[:, np.newaxis] # convert to matrix form
colors = ['red','teal', 'yellowgreen', 'purple','gold']
x_plot = np.linspace(0,1000, 1001)  # dummy range for plotting fitted curve
x_plot = x_plot[:, np.newaxis] # convert to matrix form

# scatter plot the training data
plt.scatter(x, y, color='navy', s=10, marker='o', label="training points")

# for count, degree in enumerate([1,2,3, 4, 5]):
# from the above commented part, you can see the performance from different orders
for count, degree in enumerate([4]):    
    model = make_pipeline(PolynomialFeatures(degree), Ridge(normalize = True))
    # to determin the polynomial order, we disable the regularizer
    # w = (np.linalg.inv( Xtrain.T@Xtrain + aa * np.eye(d))) @ Xtrain.T @ ytrain
    # yhat = Xtest@w
    # mse.append(np.linalg.norm(yhat - ytest))    
    model.fit(X, y)
    y_plot = model.predict(x_plot)
    plt.plot(x_plot, y_plot, color=colors[count], linewidth=1,
             label="degree, n= %d" % degree)

plt.legend(loc='best')

plt.show()



model = make_pipeline(PolynomialFeatures(degree), Ridge(normalize = True))
model.fit(X, y)

# x4 =PolynomialFeatures(5).fit_transform(X)
# mdl = Ridge(alpha=1e6).fit(x4,y)
# ypre = mdl.predict(x)
