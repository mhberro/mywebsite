#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Jul  2 02:28:57 2020

@author: PFC
"""

import numpy as np
import matplotlib.pyplot as plt

from sklearn.linear_model import LinearRegression
from sklearn.preprocessing import PolynomialFeatures
from sklearn.model_selection import cross_val_score
from sklearn.linear_model import Ridge
from sklearn.metrics import mean_squared_error
        
data= np.loadtxt('copper-new.txt')
x = data[:,1]
y = data[:,0]

                     
# expend to the polynomial features
X = x[:, np.newaxis] # convert to matrix form
X = PolynomialFeatures(4).fit_transform(X)



# Choose between following alpha stepsize will end up different result
alpha_range = np.linspace(0.00001, 0.01, 1000)   # better mse result
# alpha_range = np.linspace(0.001, 1, 1000)
mse = []
for aa in alpha_range:    
    # w = (np.linalg.inv( Xtrain.T@Xtrain + aa * np.eye(d))) @ Xtrain.T @ ytrain
    # yhat = Xtest@w
    # mse.append(np.linalg.norm(yhat - ytest))
    mdl = Ridge(normalize=True, alpha= aa)
    mse.append(-np.mean(cross_val_score(mdl, X, y, cv=5, scoring='neg_mean_squared_error')))
    
# select the best alpha    
idx = mse.index(min(mse))
best_alpha = alpha_range[idx]
best_mse = mse[idx]

# plot the curves
plt.plot(alpha_range,mse, label="mse curve")
plt.scatter(best_alpha, best_mse, marker='o',label="optimum alpha",c='red')
plt.text(alpha_range[idx], mse[idx], ("{0:.6f}".format(best_alpha), "{0:.3f}".format(best_mse)))
plt.xlabel('alpha')
plt.ylabel('MSE of test set')
plt.title('CV curve')
plt.legend(loc='best')
# plt.savefig('CV2.pdf')


# predict the new tempreture
mdl1 = Ridge(normalize=True, alpha= best_alpha).fit(X,y)
Ktest = np.array([400.])
Ktest = Ktest[:, np.newaxis]
xnew = PolynomialFeatures(4).fit_transform(Ktest)
ynew = mdl1.predict(xnew)
print('The predicted coefficient y is %.2f' % ynew)

# compare with linear regression
lr = LinearRegression().fit(x.reshape(-1,1),y)
ylr = lr.predict(Ktest)

# plot the result
xplot = np.linspace(0,1000, 10001).reshape(-1,1) # plot range 
xplot1 = PolynomialFeatures(4).fit_transform(xplot) # convert to matrix for polynomial
poly_plot = mdl1.predict(xplot1)
lr_plot = lr.predict(xplot)
plt.figure()
plt.plot(xplot, poly_plot, label='Polynomial regression',c='blue')
plt.plot(xplot, lr_plot, label='Linear regression',c='red')
plt.scatter(x, y, c = 'purple', label='training data')
plt.xlabel('Tempreture')
plt.ylabel('Thermal coefficient')
plt.legend()
# plt.savefig('compare.pdf')
plt.show()


# part a) 
print('result for part a:')
print('The linear regression parameters:')
print('y = %0.4f + %0.4fx' %(lr.intercept_, lr.coef_))
print('The fitted error for linear regression:')
print('mse: %0.4f' %mean_squared_error(lr.predict(x[:, np.newaxis]), y[:,np.newaxis]))
