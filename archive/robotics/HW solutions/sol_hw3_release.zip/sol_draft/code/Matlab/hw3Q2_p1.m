clear; close all;
rng(1)
raw = csvread('marriage.csv');
x = raw(:, 1:end-1);
y = raw(:, end);
y = categorical(y);

N = size(x, 1);

nknn = 4; % number of neighbor in knn

%% complete data set
% to achieve more accurate results, we repeat the test multiple times and
% take the average of the results.
ntrial = 100; 
rate_nb = zeros(1, ntrial);
rate_lr = zeros(1, ntrial);
rate_knn = zeros(1, ntrial);

for ii = 1:ntrial

    % data splitting
    [train_idx, test_idx] = divide_data(N, 0.8);
    nt = length(test_idx);

    % Naive Bayse
    mdl_nb = fitcnb(x(train_idx,:), y(train_idx));
    pre_nb = predict(mdl_nb, x(test_idx, :));
    rate_nb(ii) = sum(pre_nb ==y(test_idx))/nt;

    % Logistic Regression
    mdl_lr = fitclinear(x(train_idx,:), y(train_idx), 'Learner', 'logistic');
    pre_lr = predict(mdl_lr, x(test_idx,:));
    rate_lr(ii) = sum(pre_lr == y(test_idx))/nt;

    mdl_knn = fitcknn(x(train_idx,:), y(train_idx),'NumNeighbors',nknn,'Standardize',1);
    pre_knn = predict(mdl_knn, x(test_idx,:));
    rate_knn(ii) = sum(pre_knn == y(test_idx))/nt;
    
end
acc_nb = mean(rate_nb);
acc_lr = mean(rate_lr);
acc_knn = mean(rate_knn);


%% two features only

% data splitting
x = x(:, 1:2);
[train_idx, test_idx] = divide_data(N, 0.8);
nt = length(test_idx);

% Naive Bayse
mdl_nb = fitcnb(x(train_idx,:), y(train_idx));
pre_nb = predict(mdl_nb, x(test_idx, :));
acc_nb2 = sum(pre_nb ==y(test_idx))/nt;

% Logistic Regression
mdl_lr = fitclinear(x(train_idx,:), y(train_idx), 'Learner', 'logistic');
pre_lr = predict(mdl_lr, x(test_idx,:));
acc_lr2 = sum(pre_lr == y(test_idx))/nt;

% Knn
mdl_knn = fitcknn(x(train_idx,:), y(train_idx),'NumNeighbors',nknn,'Standardize',1);
pre_knn = predict(mdl_knn, x(test_idx,:));
acc_knn2 = sum(pre_knn == y(test_idx))/nt;


x1range = min(x(train_idx,1)):.01:max(x(train_idx,1));
x2range = min(x(train_idx,2)):.01:max(x(train_idx,2));

[xx1, xx2] = meshgrid(x1range,x2range);
XGrid = [xx1(:) xx2(:)];

models = {mdl_nb, mdl_lr, mdl_knn};
model_name = {'Naive Bayes','Logistic Regression','Nearest Neighbor'};

idx0 = find(y(test_idx)=='0');
idx1 = find(y(test_idx)=='1');
x0test = x(test_idx(idx0), :);
x1test = x(test_idx(idx1), :);

for ii =1:3
   predictedDivorce = predict(models{ii}, XGrid);
   subplot(2,2,ii);
   gscatter(xx1(:), xx2(:), predictedDivorce,'rgb');
   hold on;
   scatter(x0test(:, 1), x0test(:, 2), 'bo');
   hold on;
   scatter(x1test(:, 1), x1test(:, 2), 'bx');
   title(model_name{ii})
   legend off, axis tight
end
legend(categories(y),'Location',[0.35,0.01,0.35,0.05],'Orientation','Horizontal')

