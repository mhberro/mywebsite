clear; close all;
load data
load label
x = data';
y = categorical(trueLabel');
N = size(x, 1);
ntrial = 100; 

rate_nb = zeros(1, ntrial);
rate_lr = zeros(1, ntrial);
rate_knn = zeros(1, ntrial);

nb_noise_level = 1e-3;

%% training
for ii = 1:ntrial

    % data splitting
    [train_idx, test_idx] = divide_data(N, 0.8);
    nt = length(test_idx);

    % ~~~~~~~~~~~~~~  Naive Bayse ~~~~~~~~~~~~~~~
    % % training
    xt = x(train_idx,:);
    yt = y(train_idx);
    Nt = size(xt, 1);
    
    idx2 = find(yt =='2');
    idx6 = find(yt =='6');
    
    % mdl '2'
    xmean2 = mean(xt(idx2, :));
    cov2 = var(xt(idx2, :));
    [~,idx] = find(cov2< 1e-3); % find the entry whose variance is too small
    for jj = 1:length(idx)
        cov2(idx(jj)) = cov2(idx(jj)) + nb_noise_level; % add perturbation
    end
    % mdl '6'
    xmean6 = mean(xt(idx6, :));
    cov6 = var(xt(idx6, :));
    [~,idx] = find(cov6< 1e-3);
    for jj = 1:length(idx)
        cov6(idx(jj)) = cov6(idx(jj)) + nb_noise_level;
    end
    
    % % testing
    x2centered = x(test_idx,:)-repmat(xmean2,nt,1);
    x6centered = x(test_idx,:)-repmat(xmean6,nt,1);
    
    lh2 = zeros(1,nt);
    lh6 = zeros(1,nt);
    for nn = 1:nt
        lh2(nn) = -1/2* x2centered(nn,:) * diag(1./cov2) * x2centered(nn,:)';
        lh6(nn) = -1/2* x6centered(nn,:) * diag(1./cov6) * x6centered(nn,:)';
    end
    lh2 = lh2 -1/2* sum(log(cov2));
    lh6 = lh6 -1/2* sum(log(cov2)); 
    
    pre_nb_2 = lh2>=lh6;
    true_lb = (y(test_idx)=='2')';
    
    rate_nb(ii) = sum(pre_nb_2 == true_lb)/nt;

    % ~~~~~~~~~~~~~~~ Logistic Regression ~~~~~~~~~~~~~~~~~
    mdl_lr = fitclinear(x(train_idx,:), y(train_idx), 'Learner', 'logistic');
    pre_lr = predict(mdl_lr, x(test_idx,:));
    rate_lr(ii) = sum(pre_lr == y(test_idx))/nt;
    
    % ~~~~~~~~~~~~~~~ K-nearest neighbor ~~~~~~~~~~~~~~~~~
    mdl_knn = fitcknn(x(train_idx,:), y(train_idx),'NumNeighbors',5,'Standardize',1);
    pre_knn = predict(mdl_knn, x(test_idx,:));
    rate_knn(ii) = sum(pre_knn == y(test_idx))/nt;
    
end
acc_nb = mean(rate_nb);
acc_lr = mean(rate_lr);
acc_knn = mean(rate_knn);

