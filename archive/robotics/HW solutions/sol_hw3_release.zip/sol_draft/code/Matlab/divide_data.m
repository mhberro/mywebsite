function [train_idx, test_idx] =  divide_data(N, portion)
% this function shuffle the index, return the portion of which as training,
% and the rest as testing
if portion<=0 && portion >1
    error('split portion must be (0,1)')
end
a = randperm(N);
b = N*portion;
train_idx = a(1:b)';
test_idx = a(b+1:end)';
end